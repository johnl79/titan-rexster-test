-= Rexster: A Graph Server =-

Rexster is a multi-faceted graph server for Blueprints-enabled graphs.
Rexster provides a flexible extensions model for server-side components.
Rexster has a browser-based interface called The Dog House and a REPL console.

