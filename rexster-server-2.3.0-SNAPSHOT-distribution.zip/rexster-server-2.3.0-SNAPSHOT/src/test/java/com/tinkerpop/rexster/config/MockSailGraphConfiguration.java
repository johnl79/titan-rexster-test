package com.tinkerpop.rexster.config;

public class MockSailGraphConfiguration extends AbstractSailGraphConfiguration {
    public void setSailType(String sailType) {
        this.sailType = sailType;
    }
}
