package com.thinkaurelius.titan.graphdb.relations;

public enum RelationRealization {

	Property, Relationship;
	
}
