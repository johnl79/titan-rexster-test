package com.thinkaurelius.titan.graphdb.entitystatus;

import com.thinkaurelius.titan.core.TitanElement;

public interface InternalElement extends TitanElement {
	
	public void setID(long id);
	
	
}
