package com.thinkaurelius.titan.graphdb.types;

public interface EdgeLabelDefinition extends TypeDefinition {

}
