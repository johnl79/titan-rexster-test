package com.thinkaurelius.titan.graphdb.relations;

public interface InlineRelation extends InternalRelation {

	InlineRelation clone();
	
}
