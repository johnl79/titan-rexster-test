package com.thinkaurelius.titan.graphdb.types;

/**
 * (c) Matthias Broecheler (me@matthiasb.com)
 */

public enum TitanTypeClass {

    LABEL, KEY;

}
