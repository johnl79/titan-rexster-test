package com.thinkaurelius.titan.util.datastructures;

public interface Factory<O> {

	public O create();
	
}
