package com.thinkaurelius.titan.diskstorage.keycolumnvalue;

/**
* (c) Matthias Broecheler (me@matthiasb.com)
*/
public enum ConsistencyLevel {

    DEFAULT, KEY_CONSISTENT

}
