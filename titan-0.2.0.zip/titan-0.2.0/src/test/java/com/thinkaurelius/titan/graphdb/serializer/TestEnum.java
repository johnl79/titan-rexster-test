package com.thinkaurelius.titan.graphdb.serializer;

public enum TestEnum {
	
	One , Two , Three; //, Four { };
	
}
