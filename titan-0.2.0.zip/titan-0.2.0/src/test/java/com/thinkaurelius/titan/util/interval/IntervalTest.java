package com.thinkaurelius.titan.util.interval;

/**
 * (c) Matthias Broecheler (me@matthiasb.com)
 */

public class IntervalTest {
}
